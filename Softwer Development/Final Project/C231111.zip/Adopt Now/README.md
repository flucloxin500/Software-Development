# AdoteAqui

A website project about pet adoption, from week two of Resilia course.


## Demo

![App demo](images/demo.gif)


## Authors

- [@willy-r](https://www.github.com/willy-r)
